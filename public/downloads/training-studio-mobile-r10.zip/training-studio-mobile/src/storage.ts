import AsyncStorage from '@react-native-async-storage/async-storage';
import { readSavedState } from './shared/saved-data';
import { type State } from './shared/training';

// Deliberately separate from the website and any future real account store.
// AsyncStorage is unencrypted. Store no credentials, tokens, or medical records here.
const KEY = 'training-studio:mobile-local-demo:v1';
let writes: Promise<void> = Promise.resolve();
export async function readLocalState(): Promise<State | null> {
  const raw = await AsyncStorage.getItem(KEY);
  return raw === null ? null : readSavedState(raw);
}
export async function saveLocalState(state: State): Promise<void> {
  const json = JSON.stringify(state);
  readSavedState(json); // Reject invalid state before writing, as well as on read.
  const next = writes.catch(() => undefined).then(() => AsyncStorage.setItem(KEY, json));
  writes = next;
  return next;
}
export async function resetLocalState(): Promise<void> {
  const next = writes.catch(() => undefined).then(() => AsyncStorage.removeItem(KEY));
  writes = next;
  await next;
}
