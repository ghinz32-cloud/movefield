declare module '*.ttf' {
 const asset:number;
 export default asset;
}
declare module '*.jpg' {
 const asset:number;
 export default asset;
}
